package Application;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;



public class Main extends Application{
	
	
	public static void main(String[] args) throws IOException {
		launch(args);
		
	}

		

	public void start(Stage primaryStage) throws Exception {
		
		FXMLLoader loader = new FXMLLoader();
		URL url = new File("src/Vue/vueMap.fxml").toURI().toURL();
		loader.setLocation(url);
		System.out.println(loader.getLocation());
		BorderPane root = new BorderPane();
		root=loader.load();		
		Scene scene = new Scene(root,200,640);
		primaryStage.setScene(scene);
		primaryStage.show();	
	
	}

	}

