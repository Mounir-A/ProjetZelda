package Vue;

import java.io.File;
import java.io.IOException;
import Controlleur.MapLogique;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.TilePane;

public class VueMaap {

	  private TilePane tilePane;
	  private int[][] map;
	
	  
	  public VueMaap( TilePane pane) throws IOException{
			tilePane = pane;
			this.map = MapLogique.getMapLogique();
			
		}
	  
	
	  
	  public void initPlateau(){
			//parcourir le tableau
		  
	/*	  TilePane panelTerrain = new TilePane();
			panelTerrain.setPrefColumns(6);
			panelTerrain.setPrefRows(10);
*/
			
			for ( int x = 0 ; x < map.length ; x++ ) {
				for ( int y = 0 ; y < map[x].length ; y ++) {
					
					if (map[x][y]==2){					
						File f=new File("src/img/herbe2.png");
						Image herbe = new Image(f.toURI().toString(),32,32,false,false);
						tilePane.getChildren().add(new ImageView(herbe));
						
					}
					else if(map[x][y]==3){
						File g=new File("src/img/chemin.png");
						Image chemin = new Image(g.toURI().toString(),32,32,false,false);
						tilePane.getChildren().add(new ImageView(chemin));
					}
					else if(map[x][y]==1){
						File h=new File("src/img/hautes_herbes.png");
						Image hautes_herbes = new Image(h.toURI().toString(),32,32,false,false);
						tilePane.getChildren().add(new ImageView(hautes_herbes));
					}
					
					
				}
			}

			
			 // AJOUT DE TOUT LES ELEMENTS AU PANEL
	//		this.tilePane.getChildren().addAll(panelTerrain);
		  
	  }
	  
	  
	
}
