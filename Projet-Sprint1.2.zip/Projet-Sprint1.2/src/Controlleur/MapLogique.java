package Controlleur;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.TilePane;

public class MapLogique implements Initializable{
	
	 private static int[][] map;
	 private String fichierDuTerrain ;
	 private Vue.VueMaap  vuemap ;
	 
	 @FXML
	 private static BorderPane BorderScen;
	 
	@FXML
	private TilePane tilePane;
	 
	
	 
	 public MapLogique() {
			fichierDuTerrain="src/Model/map.txt";
			map = new int[6][10];
			
		}
 
 public void initMapLogique() throws IOException{
	 File fichier = new File(fichierDuTerrain);
		
		
		String ligne = "";
		BufferedReader lecteurFichier = new BufferedReader(new FileReader(fichier));
		int i = 0;
		StringTokenizer st=new StringTokenizer(ligne, ", ");
		
		do{
			int j = 0;
			ligne = lecteurFichier.readLine();
			//System.out.println(ligne);
			if(ligne!=null){ 
				
				st = new StringTokenizer(ligne, ", ");
			
				
			
				while(st.hasMoreTokens()) {
					
					map[i][j] = Integer.parseInt(st.nextToken(", "));
					//System.out.println(j+"j");
					//System.out.println(i);
					j++;
				}
				System.out.println(ligne);
				i++;
					
			}
			
			
		}while(ligne != null);
		
		lecteurFichier.close();
 }

 public static int[][] getMapLogique(){
	 return map ;
 }
 
 
 public void updateMap() {
	
 }

 @Override
	public void initialize(URL location, ResourceBundle resources) {
		
		System.out.println(map[0].length +" "+map.length );
		
		tilePane.setPrefWidth(map[0].length*32);
		tilePane.setPrefHeight(map.length*32);
		
		
		
		try {
			vuemap = new Vue.VueMaap(tilePane);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		vuemap.initPlateau();
		
	}
 
}

